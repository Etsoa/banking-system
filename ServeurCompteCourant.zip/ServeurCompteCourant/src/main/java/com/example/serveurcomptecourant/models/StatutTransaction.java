package com.example.serveurcomptecourant.models;

public enum StatutTransaction {
    en_attente, confirmee, refusee
}