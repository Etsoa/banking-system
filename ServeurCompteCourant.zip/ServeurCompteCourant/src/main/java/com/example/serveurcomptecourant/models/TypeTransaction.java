package com.example.serveurcomptecourant.models;

public enum TypeTransaction {
    retrait, depot
}