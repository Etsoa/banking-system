package com.example.echange;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/api")
public class JaxRsActivator extends Application {
    // No code needed, just activates JAX-RS
}
